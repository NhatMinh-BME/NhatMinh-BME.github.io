// ----------------------------------------------------
// This C# program reads and processes each sample in a 
// PT4 file sequentially, from the first sample to the
// last.  
//
// The name of the file to be processed is taken from 
// the command line argument. The path is relative to the executable location.
//
//
//  NOTE: This is simply used for debugging/testing/utility and is not used
//  by any of the actual PowerTool application code
//
//  Sample input files can be found in the directory 'samples'
//  (note, filepath while debuging id relative to the bin\Debug directory)
//
// Copyright (c) 2008 Monsoon Solutions, Inc.
// All Rights Reserved.
// ----------------------------------------------------

using System;
using System.IO;
using System.Diagnostics;
using System.Globalization;
using System.Text;

namespace Pt5Reader
{
    #region PT5 class
    public static class PT5
    {
        #region Constants
        // Fixed file offsets
        public const long headerOffset = 0;
        public const long statusOffset = 272;
        public const long sampleOffset = 1024;

        // Bitmasks
        private const short coarseMask = 1;
        private const ushort marker0Mask = 1;
        private const ushort marker1Mask = 2;
        private const ushort markerMask = marker0Mask | marker1Mask;

        // Missing data indicators
        private const short missingRawCurrent = unchecked((short)0x8001);
        private const ushort missingRawVoltage = unchecked((ushort)(~0));
        #endregion

        #region Structs and enums for file header
        public enum CalibrationStatus : int
        {
            OK, Failed
        }

        public enum VoutSetting : int
        {
            Typical, Low, High, Custom
        }

        [FlagsAttribute]  // bitwise-maskable
        public enum SelectField : int
        {
            None = 0x00,
            Avg = 0x01,
            Min = 0x02,
            Max = 0x04,
            Main = 0x08,
            Usb = 0x10,
            Aux = 0x20,
            Marker = 0x40,
            All = Avg | Min | Max
        }

        public enum RunMode : int
        {
            NoGUI, GUI
        }

        [FlagsAttribute] // bitwise-maskable
        public enum CaptureMask : ushort
        {
            chanMain = 0x1000,
            chanUsb = 0x2000,
            chanAux = 0x4000,
            chanMarker = 0x8000,
            chanMask = 0xf000,
        }

        // File header structure
        public struct Pt5Header
        {
            public int headSize;
            public string name;
            public int batterySize;
            public DateTime captureDate;
            public string serialNumber;
            public CalibrationStatus calibrationStatus;
            public VoutSetting voutSetting;
            public float voutValue;
            public int hardwareRate;
            public float softwareRate; // ignore
            public SelectField powerField;
            public SelectField currentField;
            public SelectField voltageField;
            public string captureSetting;
            public string swVersion;
            public RunMode runMode;
            public int exitCode;
            public long totalCount;
            public ushort statusOffset;
            public ushort statusSize;
            public ushort sampleOffset;
            public ushort sampleSize;
            public ushort initialMainVoltage;
            public ushort initialUsbVoltage;
            public ushort initialAuxVoltage;
            public CaptureMask captureDataMask;
            public ulong sampleCount;
            public ulong missingCount;
            public float avgMainVoltage;
            public float avgMainCurrent;
            public float avgMainPower;
            public float avgUsbVoltage;
            public float avgUsbCurrent;
            public float avgUsbPower;
            public float avgAuxVoltage;
            public float avgAuxCurrent;
            public float avgAuxPower;

            /// <summary>
            /// ToString display method
            /// </summary>
            /// <returns></returns>
            public override string ToString()
            {
                string str = "Pt5Header:\n" ;
                str += "headsize: " + headSize +"\n";
                str += "name: " + name+"\n";
                str += "batterySize: "+ batterySize +"\n";
                str += "captureDate: " + captureDate+"\n";
                str += "serialNumber: " +serialNumber+ "\n";
                str += "calibrationStatus : " +calibrationStatus +"\n";
                str += "voutSetting: " + voutSetting + "\n";
                str += "voutValue: " + voutValue + "\n";
                str += "hardwareRate: " + hardwareRate + "\n";
                str += "powerField: " + powerField + "\n";
                str += "currentField: " + currentField + "\n";
                str += "voltageField: " + voltageField + "\n";
                str += "captureSetting: " + captureSetting + "\n";
                str += "swVersion: " + swVersion + "\n";
                str += "runMode: " + runMode + "\n";
                str += "exitCode: " + exitCode + "\n";
                str += "totalCount: " + totalCount + "\n";
                str += "statusOffset: " + statusOffset + "\n";
                str += "statusSize: " + statusSize + "\n";
                str += "initialMainVoltage: " + initialMainVoltage + "\n";
                str += "initialUsbVoltage: " + initialUsbVoltage + "\n";
                str += "initialAuxVoltage: " + initialAuxVoltage + "\n";
                str += "captureDataMask: 0x" + ((int)captureDataMask).ToString("x4") + "\n";
                str += "sampleCount: " + sampleCount + "\n";
                str += "missingCount: " + missingCount + "\n";
                str += "avgMainVoltage: " + avgMainVoltage + "\n";
                str += "avgMainCurrent: " + avgMainCurrent + "\n";
                str += "avgMainPower: " + avgMainPower + "\n";
                str += "avgUsbVoltage: " + avgUsbVoltage + "\n";
                str += "avgUsbCurrent: " + avgUsbCurrent + "\n";
                str += "avgUsbPower: " + avgUsbPower + "\n";
                str += "avgAuxVoltage: " + avgAuxVoltage + "\n";
                str += "avgAuxCurrent: " + avgAuxCurrent + "\n";
                str += "avgAuxPower: " + avgAuxPower + "\n";
                return str;
            }
        }
        #endregion

        #region Structs and enums for Status packet
        public enum PacketType : byte
        {
            set = 1, start, stop,
            status = 0x10, sample = 0x20
        }

        public struct Observation
        {
            public short mainCurrent;
            public short usbCurrent;
            public short auxCurrent;
            public ushort voltage;
        }

        [FlagsAttribute]
        public enum PmStatus : byte
        {
            unitNotAtVoltage = 0x01,
            cannotPowerOutput = 0x02,
            checksumError = 0x04,
            followsLastSamplePacket = 0x08,
            responseToStopPacket = 0x10,
            responseToResetCommand = 0x20,
            badPacketReceived = 0x40,
        }

        [FlagsAttribute]
        public enum Leds : byte
        {
            disableButtonPressed = 0x01,
            errorLedOn = 0x02,
            fanMotorOn = 0x04,
            voltageIsAux = 0x08,
        }

        public enum HardwareRev : byte
        {
            revA = 1, revB, revC, revD,
        }

        public enum UsbPassthroughMode : byte
        {
            off, on, auto, trigger, sync,
        }

        public enum EventCode : byte
        {
            noEvent = 0,
            usbConnectionLost,
            tooManyDroppedObservations,
            resetRequestedByHost,
        }

        // Status packet structure
        public struct StatusPacket
        {
            public byte length;                                     // packet length (not incl. this byte)
            public PacketType type;                                 // packet type (PacketType.status)
            public byte firmwareVersion;                            // firmware version
            public byte protocolVersion;                            // protocol version
            public Observation fineObs;                             // fine-scale measurement
            public Observation coarseObs;                           // coarse-scale measurement
            public byte mainVoltageSetting;                         // main voltage setting (volts = 2.0 + 0.01*mainVoltageSetting)
            public sbyte temperature;                               // signed degrees Celsius (-128...+127)
            public byte pmStatus;                                   // see bitmasks in pmStatus enum
            public byte reserved;                                   // reserved for future use
            public Leds leds;                                       // see masks in pmLeds enum
            public sbyte mainFineResistorOffset;                    // signed, ohms = 0.05 + 0.0001*offset
            public ushort serialNumber;                             // two-byte serial number (big endian)
            public byte sampleRate;                                 // sample rate (kHz)
            public ushort dacCalLow;                                // DAC calibration setting for 2.5V
            public ushort dacCalHigh;                               // DAC calibration setting for 4.096V
            public ushort powerupCurrentLimit;                      
            public ushort runtimeCurrentLimit;                      
            public byte powerupTime;                                // ms
            public sbyte usbFineResistorOffset;                     // signed, ohms = 0.05 + 0.0001*offset
            public sbyte auxFineResistorOffset;                     // signed, ohms = 0.10 + 0.0001*offset
            public ushort usbVoltage;                               // volts = 2 * usbVoltage * 62.5 / 1e6
            public ushort auxVoltage;                               // volts =     auxVoltage * 62.5 / 1e6 (*2 for Rev C boards)
            public HardwareRev hardwareRevision;                           // 1=A, 2=B., etc...
            public float temperatureLimit;                          // Signed Q7.8 format
            public UsbPassthroughMode usbPassthroughMode;           // 0=off, 1=on, 2=auto
            public sbyte mainCoarseResistorOffset;                  // signed, ohms = 0.05 + 0.0001*offset
            public sbyte usbCoarseResistorOffset;                   // signed, ohms = 0.05 + 0.0001*offset
            public sbyte auxCoarseResistorOffset;                   // signed, ohms = 0.10 + 0.0001*offset
            public sbyte factoryMainFineResistorOffset;             // signed, ohms = 0.05 + 0.0001*offset
            public sbyte factoryUsbFineResistorOffset;              // signed, ohms = 0.05 + 0.0001*offset
            public sbyte factoryAuxFineResistorOffset;              // signed, ohms = 0.10 + 0.0001*offset
            public sbyte factoryMainCoarseResistorOffset;           // signed, ohms = 0.05 + 0.0001*offset
            public sbyte factoryUsbCoarseResistorOffset;            // signed, ohms = 0.05 + 0.0001*offset
            public sbyte factoryAuxCoarseResistorOffset;            // signed, ohms = 0.10 + 0.0001*offset
            public EventCode eventCode;                                  // event code
            public ushort eventData;                                // event data


            //HVPM Protocol Fields
            public byte measurementDataset;                         // 00 = Main + USB, 01 = BNC + USB
            public int HVmainVoltageSetting;                        //Main Vout
            public UInt32 mainFineScale;                            //Current scaling by channel.  
            public UInt32 mainCoarseScale;                          //Current scaling by channel. 
            public UInt32 usbFineScale;                             //Current scaling by channel.  
            public UInt32 usbCoarseScale;                           //Current scaling by channel.  
            public UInt32 auxFineScale;                             //Current scaling by channel.  
            public UInt32 auxCoarseScale;                           //Current scaling by channel.  
            public short mainFineZeroOffset;                        //Zero-level offset for the PGA. 
            public short mainCoarseZeroOffset;                      //Zero-level offset for the PGA.
            public short USBFineZeroOffset;                         //Zero-level offset for the PGA.
            public short USBCoarseZeroOffset;                       //Zero-level offset for the PGA.
            public byte hardwareModel;                              //0 = unknown, 1 = 5V, 2 = HV
            public byte checksum;                                   // checksum
        }
        #endregion
        
        #region Sample struct
        public struct Sample
        {
            public long sampleIndex;   // 0...N-1
            public double timeStamp;   // fractional seconds

            public bool mainPresent;   // whether Main was recorded
            public double mainCurrent; // current in milliamps
            public double mainVoltage; // volts

            public bool usbPresent;    // whether Usb was recorded
            public double usbCurrent;  // current in milliamps
            public double usbVoltage;  // volts

            public bool auxPresent;    // whether Aux was recorded
            public double auxCurrent;  // current in milliamps
            public double auxVoltage;  // volts;

            public bool markerPresent; // whether markers/voltages 
                                       //      were recorded
            public bool marker0;       // Marker 0
            public bool marker1;       // Marker 1
            public bool missing;       // true if this sample was
                                       //      missing
        }
        #endregion
        
        #region Read file header
        static public void ReadHeader(BinaryReader reader,
                                      ref Pt5Header header)
        {
            // Remember original position
            long oldPos = reader.BaseStream.Position;

            // Move to start of file
            reader.BaseStream.Position = 0;

            // Read file header
            header.headSize = reader.ReadInt32();
            header.name = reader.ReadString().Trim();
            header.batterySize = reader.ReadInt32();
            header.captureDate =
                   DateTime.FromBinary(reader.ReadInt64());
            Console.WriteLine("capture date: " + header.captureDate.ToString());
            header.serialNumber = reader.ReadString().Trim();
            header.calibrationStatus =
                   (CalibrationStatus)reader.ReadInt32();
            header.voutSetting = (VoutSetting)reader.ReadInt32();
            header.voutValue = reader.ReadSingle();
            header.hardwareRate = reader.ReadInt32();
            header.softwareRate = (float)header.hardwareRate;
            reader.ReadSingle(); // ignore software rate
            header.powerField = (SelectField)reader.ReadInt32();
            header.currentField = (SelectField)reader.ReadInt32();
            header.voltageField = (SelectField)reader.ReadInt32();
            header.captureSetting = reader.ReadString().Trim();
            header.swVersion = reader.ReadString().Trim();
            header.runMode = (RunMode)reader.ReadInt32();
            header.exitCode = reader.ReadInt32();
            header.totalCount = reader.ReadInt64();
            header.statusOffset = reader.ReadUInt16();
            header.statusSize = reader.ReadUInt16();
            header.sampleOffset = reader.ReadUInt16();
            header.sampleSize = reader.ReadUInt16();
            header.initialMainVoltage = reader.ReadUInt16();
            header.initialUsbVoltage = reader.ReadUInt16();
            header.initialAuxVoltage = reader.ReadUInt16();
            header.captureDataMask = (CaptureMask)reader.ReadUInt16();
            header.sampleCount = reader.ReadUInt64();
            header.missingCount = reader.ReadUInt64();

            // Convert sums to averages
            ulong count = Math.Max(1, header.sampleCount -
                                      header.missingCount);
            header.avgMainVoltage = count > 0 ? reader.ReadSingle() / count : 0;
            header.avgMainCurrent = count > 0 ? reader.ReadSingle() / count : 0;
            header.avgMainPower = count > 0 ? reader.ReadSingle() / count : 0;
            header.avgUsbVoltage = count > 0 ? reader.ReadSingle() / count : 0;
            header.avgUsbCurrent = count > 0 ? reader.ReadSingle() / count : 0;
            header.avgUsbPower = count > 0 ? reader.ReadSingle() / count : 0;
            header.avgAuxVoltage = count > 0 ? reader.ReadSingle() / count : 0;
            header.avgAuxCurrent = count > 0 ? reader.ReadSingle() / count : 0;
            header.avgAuxPower = count > 0 ? reader.ReadSingle() / count : 0;

            // Restore original position
            reader.BaseStream.Position = oldPos;
        }
        #endregion

        #region Read status packet
        static public void ReadStatusPacket(BinaryReader reader, 
                                            ref StatusPacket status)
        {
            // Remember original position
            long oldPos = reader.BaseStream.Position;

            // Move to start of status packet
            reader.BaseStream.Position = statusOffset;

            // Read status packet
            status.length = reader.ReadByte();
            status.type = (PacketType)reader.ReadByte();
            Debug.Assert(status.type == PacketType.status);
            status.firmwareVersion = reader.ReadByte();
            status.protocolVersion = reader.ReadByte();
            status.fineObs.mainCurrent = reader.ReadInt16();
            status.fineObs.usbCurrent = reader.ReadInt16();
            status.fineObs.auxCurrent = reader.ReadInt16();
            status.fineObs.voltage = reader.ReadUInt16();
            status.coarseObs.mainCurrent = reader.ReadInt16();
            status.coarseObs.usbCurrent = reader.ReadInt16();
            status.coarseObs.auxCurrent = reader.ReadInt16();
            status.coarseObs.voltage = reader.ReadUInt16();
            status.mainVoltageSetting = reader.ReadByte();
            status.temperature = reader.ReadSByte();
            status.pmStatus = reader.ReadByte();
            status.reserved = reader.ReadByte();
            status.leds = (Leds)reader.ReadByte();
            status.mainFineResistorOffset = reader.ReadSByte();
            status.serialNumber = reader.ReadUInt16();
            status.sampleRate = reader.ReadByte();
            status.dacCalLow = reader.ReadUInt16();
            status.dacCalHigh = reader.ReadUInt16();
            status.powerupCurrentLimit = reader.ReadUInt16();
            status.runtimeCurrentLimit = reader.ReadUInt16();
            status.powerupTime = reader.ReadByte();
            status.usbFineResistorOffset = reader.ReadSByte();
            status.auxFineResistorOffset = reader.ReadSByte();
            status.usbVoltage = reader.ReadUInt16();
            status.usbVoltage = reader.ReadUInt16();
            status.hardwareRevision = (HardwareRev)reader.ReadByte();
            status.temperatureLimit = reader.ReadByte();
            status.usbPassthroughMode =
                       (UsbPassthroughMode)reader.ReadByte();
            status.mainCoarseResistorOffset = reader.ReadSByte();
            status.usbCoarseResistorOffset = reader.ReadSByte();
            status.auxCoarseResistorOffset = reader.ReadSByte();
            status.factoryMainFineResistorOffset = reader.ReadSByte();
            status.factoryUsbFineResistorOffset = reader.ReadSByte();
            status.factoryAuxFineResistorOffset = reader.ReadSByte();
            status.factoryMainCoarseResistorOffset =
                       reader.ReadSByte();
            status.factoryUsbCoarseResistorOffset =
                       reader.ReadSByte();
            status.factoryAuxCoarseResistorOffset =
                       reader.ReadSByte();
            status.eventCode = (EventCode)reader.ReadByte();
            status.eventData = reader.ReadUInt16();

            status.measurementDataset = reader.ReadByte();
            status.HVmainVoltageSetting = reader.ReadInt16();
            status.mainFineScale = reader.ReadUInt32();
            status.mainCoarseScale = reader.ReadUInt32();
            status.usbFineScale = reader.ReadUInt32();
            status.usbCoarseScale = reader.ReadUInt32();
            status.auxFineScale = reader.ReadUInt32();
            status.auxCoarseScale = reader.ReadUInt32();
            status.mainFineZeroOffset = reader.ReadInt16();
            status.mainCoarseZeroOffset = reader.ReadInt16();
            status.USBFineZeroOffset = reader.ReadInt16();
            status.USBCoarseZeroOffset = reader.ReadInt16();
            status.hardwareModel = reader.ReadByte();
            status.checksum = reader.ReadByte();

            // Restore original position
            reader.BaseStream.Position = oldPos;
        }
        #endregion

        #region Utility functions
        static public long BytesPerSample(CaptureMask captureDataMask)
        {
            long result = sizeof(ushort); // voltage is always present

            // Add lengths for optional current channels
            if ((captureDataMask & CaptureMask.chanMain) != 0)
                result += sizeof(UInt32);

            if ((captureDataMask & CaptureMask.chanUsb) != 0)
                result += sizeof(UInt32);

            if ((captureDataMask & CaptureMask.chanAux) != 0)
                result += sizeof(UInt32);

            return result;
        }

        static public long SamplePosition(long sampleIndex,
                                          CaptureMask captureDataMask)
        {
            long result = sampleOffset +
                BytesPerSample(captureDataMask) * sampleIndex;

            return result;
        }

        static public long SamplePosition(double seconds,
                                   CaptureMask captureDataMask,
                                   ref StatusPacket statusPacket)
        {
            seconds = Math.Max(0, seconds);

            long bytesPerSample = BytesPerSample(captureDataMask);
            long freq = 1000 * statusPacket.sampleRate;

            long result = (long)(seconds * freq * bytesPerSample);
            long err = result % bytesPerSample;
            if (err > 0)   // must fall on boundary
                result += (bytesPerSample - err);
            result += sampleOffset;

            return result;
        }

        static public long SampleCount(BinaryReader reader,
                                       CaptureMask captureDataMask)
        {
            return (reader.BaseStream.Length - sampleOffset)
                   / BytesPerSample(captureDataMask);
        }
        #endregion


        #region Retrieve a sample from the file
        static public void GetSample(long sampleIndex,
                              CaptureMask captureDataMask,
                              StatusPacket statusPacket,
                              BinaryReader reader,
                              ref Sample sample)
        {
            int intToFloatConversion = 1048576;
            // Remember the index and time
            sample.sampleIndex = sampleIndex;
            sample.timeStamp = sampleIndex 
                               / (1000.0 * statusPacket.sampleRate);

            // Intial settings for all flags
            sample.mainPresent = 
                  (captureDataMask & CaptureMask.chanMain) != 0;
            sample.usbPresent = 
                  (captureDataMask & CaptureMask.chanUsb) != 0;
            sample.auxPresent = 
                  (captureDataMask & CaptureMask.chanAux) != 0;
            sample.markerPresent = true;
            sample.missing = false;

            // Abort if no data was selected
            long bytesPerSample = BytesPerSample(captureDataMask);
            if (bytesPerSample == 0)
                return;

            // Remember original position
            long oldPos = reader.BaseStream.Position;

            // Position the file to the start of the desired sample (if necessary)
            long newPos = SamplePosition(sampleIndex, captureDataMask);
            if (oldPos != newPos)
                reader.BaseStream.Position = newPos;

            // Get default voltages (V) for the three channels
            sample.mainVoltage =
                statusPacket.HVmainVoltageSetting / intToFloatConversion;

            sample.usbVoltage =
                (double)statusPacket.usbVoltage * 125 / 1e6f;
            if (statusPacket.hardwareRevision < HardwareRev.revB)
                sample.usbVoltage /= 2;

            sample.auxVoltage =
                (double)statusPacket.auxVoltage * 125 / 1e6f;
            if (statusPacket.hardwareRevision < HardwareRev.revC)
                sample.auxVoltage /= 2;

            // Main current (mA)
            if (sample.mainPresent)
            {
                Int32 raw = reader.ReadInt32();

                sample.missing = sample.missing || 
                                 raw == missingRawCurrent;
                if (!sample.missing)
                {
                    sample.mainCurrent = raw / 1000f;   // uA -> mA
                }
            }

            // USB current (mA)
            if (sample.usbPresent)
            {
                Int32 raw = reader.ReadInt32();

                sample.missing = sample.missing || 
                                 raw == missingRawCurrent;
                if (!sample.missing)
                {
                    sample.usbCurrent = raw / 1000f;   // uA -> mA
                }
            }

            // Aux current (mA)
            if (sample.auxPresent)
            {
                Int32 raw = reader.ReadInt32();

                sample.missing = sample.missing || 
                                 raw == missingRawCurrent;
                if (!sample.missing)
                {
                    sample.auxCurrent = raw / 1000f;   // uA -> mA

                }
            }

            // Markers and Voltage (V)
            {
                ushort uraw = reader.ReadUInt16();

                sample.missing = sample.missing ||                    
                                 uraw == missingRawVoltage;
                if (!sample.missing)
                {
                    // Strip out marker bits
                    sample.marker0 = (uraw & marker0Mask) != 0;
                    sample.marker1 = (uraw & marker1Mask) != 0;
                    uraw &= unchecked((ushort)~markerMask);

                    // Calculate voltage
                    double voltage = (double)uraw * 125 / 1e6f*4;

                    // Assign the high-res voltage, as appropriate
                    if ((statusPacket.leds & Leds.voltageIsAux) != 0)
                    {
                        sample.auxVoltage = voltage;
                        if (statusPacket.hardwareRevision 
                               < HardwareRev.revC)
                        {
                            sample.auxVoltage /= 2;
                        }
                    }
                    else
                    {
                        sample.mainVoltage = voltage;
                        if (statusPacket.hardwareRevision 
                               < HardwareRev.revB)
                        {
                            sample.mainVoltage /= 2;
                        }
                    }
                }
            }

            // Restore original position, if we moved it earlier
            if (oldPos != newPos)
                reader.BaseStream.Position = oldPos;
        }
        #endregion
    }
    #endregion

    #region Main program
    class Program
    {
        private enum ChannelSelection
        {
            Unknown,
            Main,
            Usb,
            Aux
        }

        private static ChannelSelection DetermineChannelToExport(PT5.Pt5Header header)
        {
            bool mainCaptured = (header.captureDataMask & PT5.CaptureMask.chanMain) != 0;
            bool usbCaptured = (header.captureDataMask & PT5.CaptureMask.chanUsb) != 0;
            bool auxCaptured = (header.captureDataMask & PT5.CaptureMask.chanAux) != 0;

            if (mainCaptured && !usbCaptured)
                return ChannelSelection.Main;
            if (!mainCaptured && usbCaptured)
                return ChannelSelection.Usb;
            if (!mainCaptured && !usbCaptured && auxCaptured)
                return ChannelSelection.Aux;

            if (mainCaptured && usbCaptured)
            {
                double mainMagnitude = Math.Abs(header.avgMainCurrent) + Math.Abs(header.avgMainPower);
                double usbMagnitude = Math.Abs(header.avgUsbCurrent) + Math.Abs(header.avgUsbPower);

                if (mainMagnitude <= 0 && usbMagnitude > 0)
                    return ChannelSelection.Usb;
                if (usbMagnitude <= 0 && mainMagnitude > 0)
                    return ChannelSelection.Main;
                return mainMagnitude >= usbMagnitude ? ChannelSelection.Main : ChannelSelection.Usb;
            }

            return ChannelSelection.Unknown;
        }

        private static bool TryGetChannelMeasurements(PT5.Sample sample,
                                                       ChannelSelection channel,
                                                       out double currentMilliAmps,
                                                       out double voltageVolts)
        {
            currentMilliAmps = 0;
            voltageVolts = 0;

            if (sample.missing)
                return false;

            switch (channel)
            {
                case ChannelSelection.Main:
                    if (!sample.mainPresent)
                        return false;
                    currentMilliAmps = sample.mainCurrent;
                    voltageVolts = sample.mainVoltage;
                    return true;
                case ChannelSelection.Usb:
                    if (!sample.usbPresent)
                        return false;
                    currentMilliAmps = sample.usbCurrent;
                    voltageVolts = sample.usbVoltage;
                    return true;
                case ChannelSelection.Aux:
                    if (!sample.auxPresent)
                        return false;
                    currentMilliAmps = sample.auxCurrent;
                    voltageVolts = sample.auxVoltage;
                    return true;
                default:
                    return false;
            }
        }

        private enum ExportFormat
        {
            Power,  // Seconds,Power_mW (default)
            Epoch,  // EpochSeconds,Voltage_V,Current_mA,Power_mW
            VI,     // Seconds,Voltage_V,Current_mA
            All     // Seconds,Voltage_V,Current_mA,Power_mW
        }

        private static bool TryParseFormat(string text, out ExportFormat format)
        {
            switch ((text ?? "").Trim().ToLowerInvariant())
            {
                case "power":
                case "p":
                    format = ExportFormat.Power; return true;
                case "epoch":
                case "e":
                    format = ExportFormat.Epoch; return true;
                case "vi":
                case "v":
                    format = ExportFormat.VI; return true;
                case "all":
                case "a":
                    format = ExportFormat.All; return true;
                default:
                    format = ExportFormat.Power; return false;
            }
        }

        private static void PrintUsage(string baseDirectory)
        {
            Console.WriteLine("PT5 Reader");
            Console.WriteLine("Usage:");
            Console.WriteLine("  Pt5Reader.exe [-f <format>] <path-to-file.pt5>");
            Console.WriteLine("  Pt5Reader.exe [-f <format>] -all");
            Console.WriteLine("  Pt5Reader.exe -i <path-to-file.pt5>    (print device info and status, no CSV)");
            Console.WriteLine("  Pt5Reader.exe -i -all");
            Console.WriteLine();
            Console.WriteLine("Formats (-f / --format), default is power:");
            Console.WriteLine("  power  Seconds,Power_mW");
            Console.WriteLine("  epoch  EpochSeconds,Voltage_V,Current_mA,Power_mW");
            Console.WriteLine("  vi     Seconds,Voltage_V,Current_mA");
            Console.WriteLine("  all    Seconds,Voltage_V,Current_mA,Power_mW");
            Console.WriteLine();
            Console.WriteLine("Info (-i / --info): print capture header and device status, then exit.");
            Console.WriteLine();
            Console.WriteLine("Example: Pt5Reader.exe samples{0}samplefile.pt5", Path.DirectorySeparatorChar);
            Console.WriteLine("Use -all or run directly .exe to convert every .pt5 file located next to the executable ({0}).", baseDirectory);
        }

        private static void PrintDeviceInfo(PT5.Pt5Header header, PT5.StatusPacket s)
        {
            CultureInfo ci = CultureInfo.InvariantCulture;
            string hwModel = s.hardwareModel == 1 ? "5V (LVPM)"
                           : s.hardwareModel == 2 ? "HV (HVPM)" : "Unknown";

            Console.WriteLine("=== Device ===");
            Console.WriteLine("Serial number (header)  : {0}", header.serialNumber);
            Console.WriteLine("Serial number (device)  : {0}", s.serialNumber);
            Console.WriteLine("Hardware model          : {0}", hwModel);
            Console.WriteLine("Hardware revision       : {0}", s.hardwareRevision);
            Console.WriteLine("Firmware version        : {0}", s.firmwareVersion);
            Console.WriteLine("Protocol version        : {0}", s.protocolVersion);
            Console.WriteLine("PowerTool version       : {0}", header.swVersion);
            Console.WriteLine("Calibration status      : {0}", header.calibrationStatus);
            Console.WriteLine();

            Console.WriteLine("=== Capture ===");
            Console.WriteLine("Name                    : {0}", header.name);
            Console.WriteLine("Capture date            : {0}", header.captureDate);
            Console.WriteLine("Capture setting         : {0}", header.captureSetting);
            Console.WriteLine("Channels captured       : {0}", header.captureDataMask);
            Console.WriteLine("Sample rate             : {0} kHz", s.sampleRate);
            Console.WriteLine("Sample count            : {0}", header.sampleCount);
            Console.WriteLine("Missing samples         : {0}", header.missingCount);
            Console.WriteLine("Duration                : {0:F3} s",
                              s.sampleRate > 0 ? header.sampleCount / (1000.0 * s.sampleRate) : 0);
            Console.WriteLine("Vout setting            : {0} ({1} V)", header.voutSetting,
                              header.voutValue.ToString("F3", ci));
            Console.WriteLine("Run mode / exit code    : {0} / {1}", header.runMode, header.exitCode);
            Console.WriteLine();

            Console.WriteLine("=== Averages ===");
            Console.WriteLine("Main : {0:F3} V  {1:F3} mA  {2:F3} mW",
                              header.avgMainVoltage, header.avgMainCurrent, header.avgMainPower);
            Console.WriteLine("USB  : {0:F3} V  {1:F3} mA  {2:F3} mW",
                              header.avgUsbVoltage, header.avgUsbCurrent, header.avgUsbPower);
            Console.WriteLine("Aux  : {0:F3} V  {1:F3} mA  {2:F3} mW",
                              header.avgAuxVoltage, header.avgAuxCurrent, header.avgAuxPower);
            Console.WriteLine();

            Console.WriteLine("=== Status at capture start ===");
            Console.WriteLine("Main voltage setting    : {0:F2} V", 2.0 + 0.01 * s.mainVoltageSetting);
            Console.WriteLine("Temperature             : {0} C (limit {1})", s.temperature, s.temperatureLimit);
            Console.WriteLine("PM status flags         : {0}", (PT5.PmStatus)s.pmStatus);
            Console.WriteLine("LEDs                    : {0}", s.leds);
            Console.WriteLine("USB passthrough mode    : {0}", s.usbPassthroughMode);
            Console.WriteLine("Power-up current limit  : {0}", s.powerupCurrentLimit);
            Console.WriteLine("Runtime current limit   : {0}", s.runtimeCurrentLimit);
            Console.WriteLine("Power-up time           : {0} ms", s.powerupTime);
            Console.WriteLine("DAC cal low / high      : {0} / {1}", s.dacCalLow, s.dacCalHigh);
            Console.WriteLine("Event                   : {0} (data {1})", s.eventCode, s.eventData);
            Console.WriteLine("Measurement dataset     : {0}", s.measurementDataset == 0 ? "Main + USB" : "BNC + USB");
            Console.WriteLine("Fine scale main/usb/aux     : {0} / {1} / {2}", s.mainFineScale, s.usbFineScale, s.auxFineScale);
            Console.WriteLine("Coarse scale main/usb/aux   : {0} / {1} / {2}", s.mainCoarseScale, s.usbCoarseScale, s.auxCoarseScale);
            Console.WriteLine("Zero offset fine main/usb   : {0} / {1}", s.mainFineZeroOffset, s.USBFineZeroOffset);
            Console.WriteLine("Zero offset coarse main/usb : {0} / {1}", s.mainCoarseZeroOffset, s.USBCoarseZeroOffset);
            Console.WriteLine("Resistor offset fine main/usb/aux   : {0} / {1} / {2}",
                              s.mainFineResistorOffset, s.usbFineResistorOffset, s.auxFineResistorOffset);
            Console.WriteLine("Resistor offset coarse main/usb/aux : {0} / {1} / {2}",
                              s.mainCoarseResistorOffset, s.usbCoarseResistorOffset, s.auxCoarseResistorOffset);
        }

        private static void ProcessAllPt5Files(string baseDirectory, ExportFormat format, bool infoOnly)
        {
            string[] pt5Files = Directory.GetFiles(baseDirectory, "*.pt5", SearchOption.TopDirectoryOnly);
            if (pt5Files.Length == 0)
            {
                Console.WriteLine("No .pt5 files found in {0}", baseDirectory);
                PrintUsage(baseDirectory);
                return;
            }

            foreach (string file in pt5Files)
            {
                ProcessPt5File(file, format, infoOnly);
            }
        }

        private static void ProcessPt5File(string fileName, ExportFormat format, bool infoOnly)
        {
            if (string.IsNullOrWhiteSpace(fileName))
            {
                Console.WriteLine("A PT5 filename is required.");
                return;
            }

            string fullPath = Path.GetFullPath(fileName);

            if (!File.Exists(fullPath))
            {
                Console.WriteLine("File not found: {0}", fullPath);
                return;
            }
            Console.WriteLine("reading in file: " + fullPath);

            using (FileStream pt5Stream = File.Open(fullPath,
                                                    FileMode.Open,
                                                    FileAccess.Read,
                                                    FileShare.ReadWrite))
            using (BinaryReader pt5Reader = new BinaryReader(pt5Stream))
            {
                // Read the file header
                PT5.Pt5Header header = new PT5.Pt5Header();
                PT5.ReadHeader(pt5Reader, ref header);
                if (!fullPath.EndsWith(".pt5", StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine("Exiting, PT3 or PT4 file found.  Only PT5 format files are fully supported.");
                    return;
                }

                // Read the Status Packet
                PT5.StatusPacket statusPacket = new PT5.StatusPacket();
                PT5.ReadStatusPacket(pt5Reader, ref statusPacket);

                if (infoOnly)
                {
                    PrintDeviceInfo(header, statusPacket);
                    return;
                }
                Console.WriteLine("header : " + header.ToString());

                // Determine the number of samples in the file
                long sampleCount = PT5.SampleCount(pt5Reader,
                                                   header.captureDataMask);
#if DEBUG
                Console.WriteLine("Sample count :" + sampleCount);
#endif
                ChannelSelection exportChannel = DetermineChannelToExport(header);
                string csvPath = Path.ChangeExtension(fullPath, ".csv");
                StreamWriter csvWriter = null;
                CultureInfo invariantCulture = CultureInfo.InvariantCulture;

                try
                {
                    if (exportChannel != ChannelSelection.Unknown)
                    {
                        csvWriter = new StreamWriter(csvPath, false, Encoding.ASCII);
                        switch (format)
                        {
                            case ExportFormat.Epoch:
                                csvWriter.WriteLine("EpochSeconds,Voltage_V,Current_mA,Power_mW");
                                break;
                            case ExportFormat.VI:
                                csvWriter.WriteLine("Seconds,Voltage_V,Current_mA");
                                break;
                            case ExportFormat.All:
                                csvWriter.WriteLine("Seconds,Voltage_V,Current_mA,Power_mW");
                                break;
                            default:
                                csvWriter.WriteLine("Seconds,Power_mW");
                                break;
                        }
                        Console.WriteLine("Exporting {0} channel data to {1}", exportChannel, csvPath);
                    }
                    else
                    {
                        Console.WriteLine("No channel data available to export.");
                    }

                    // Pre-position input file to the beginning of the sample 
                    // data (saves a lot of repositioning in the GetSample 
                    // routine)
                    pt5Reader.BaseStream.Position = PT5.sampleOffset;

                    long missingCount = 0;

                    DateTime captureStartUtc = header.captureDate.Kind == DateTimeKind.Unspecified
                        ? DateTime.SpecifyKind(header.captureDate, DateTimeKind.Utc)
                        : header.captureDate.ToUniversalTime();
                    DateTime unixEpoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
                    double captureStartEpochSeconds = (captureStartUtc - unixEpoch).TotalSeconds;

                    // Process the samples sequentially, beginning to end
                    PT5.Sample sample = new PT5.Sample();
                    for (long sampleIndex = 0;
                         sampleIndex < sampleCount;
                         sampleIndex++)
                    {
                        // Read the next sample
                        PT5.GetSample(sampleIndex, header.captureDataMask,
                                      statusPacket, pt5Reader, ref sample);
#if DEBUG
                        //Console.WriteLine("#{0} {1} sec MAIN: {2} mA {3} V USB: {4} mA {5} V",
                        //                  sampleIndex,
                        //                  sample.timeStamp,
                        //                  sample.mainCurrent,
                        //                  sample.mainVoltage,
                        //                  sample.usbCurrent,
                        //                  sample.usbVoltage);
#endif

                        if (csvWriter != null &&
                            TryGetChannelMeasurements(sample, exportChannel, out double currentMilliAmps, out double voltageVolts))
                        {
                            double powerMilliWatts = currentMilliAmps * voltageVolts;
                            string csvLine;
                            switch (format)
                            {
                                case ExportFormat.Epoch:
                                    csvLine = string.Format(invariantCulture,
                                                            "{0:F5},{1:F3},{2:F3},{3:F6}",
                                                            captureStartEpochSeconds + sample.timeStamp,
                                                            voltageVolts,
                                                            currentMilliAmps,
                                                            powerMilliWatts);
                                    break;
                                case ExportFormat.VI:
                                    csvLine = string.Format(invariantCulture,
                                                            "{0:F5},{1:F3},{2:F3}",
                                                            sample.timeStamp,
                                                            voltageVolts,
                                                            currentMilliAmps);
                                    break;
                                case ExportFormat.All:
                                    csvLine = string.Format(invariantCulture,
                                                            "{0:F5},{1:F3},{2:F3},{3:F6}",
                                                            sample.timeStamp,
                                                            voltageVolts,
                                                            currentMilliAmps,
                                                            powerMilliWatts);
                                    break;
                                default:
                                    csvLine = string.Format(invariantCulture,
                                                            "{0:F5},{1:F6}",
                                                            sample.timeStamp,
                                                            powerMilliWatts);
                                    break;
                            }
                            csvWriter.WriteLine(csvLine);
                        }

                        if (sample.missing)
                            missingCount++;
                    }
                }
                finally
                {
                    csvWriter?.Dispose();
                }
            }
        }

        static void Main(string[] args)
        {
            string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;

            ExportFormat format = ExportFormat.Power;
            bool all = false;
            bool infoOnly = false;
            string file = null;

            for (int i = 0; i < args.Length; i++)
            {
                string arg = args[i];
                if (string.Equals(arg, "-f", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(arg, "--format", StringComparison.OrdinalIgnoreCase))
                {
                    if (i + 1 >= args.Length || !TryParseFormat(args[++i], out format))
                    {
                        Console.WriteLine("Unknown or missing format.");
                        PrintUsage(baseDirectory);
                        return;
                    }
                }
                else if (string.Equals(arg, "-i", StringComparison.OrdinalIgnoreCase) ||
                         string.Equals(arg, "--info", StringComparison.OrdinalIgnoreCase))
                {
                    infoOnly = true;
                }
                else if (string.Equals(arg, "-all", StringComparison.OrdinalIgnoreCase))
                {
                    all = true;
                }
                else if (string.Equals(arg, "-h", StringComparison.OrdinalIgnoreCase) ||
                         string.Equals(arg, "--help", StringComparison.OrdinalIgnoreCase))
                {
                    PrintUsage(baseDirectory);
                    return;
                }
                else
                {
                    file = arg;
                }
            }

            if (file != null && !all)
            {
                ProcessPt5File(file, format, infoOnly);
            }
            else
            {
                ProcessAllPt5Files(baseDirectory, format, infoOnly);
            }
            Console.WriteLine("Please press Enter to exit...");
            Console.ReadLine();
        }
    }
#endregion
}

